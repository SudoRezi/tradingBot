# AI Crypto Trading Bot - macOS Installation

## Quick Start

1. Open Terminal
2. Navigate to this folder: `cd /path/to/this/folder`
3. Run: `./install.sh`
4. Follow the installation prompts
5. Configure API keys in .env file
6. Run `tradingbot` from terminal or use AI Trading Bot.app

## Requirements

- macOS 10.15+ (Intel or Apple Silicon)
- Xcode Command Line Tools
- Internet connection

## Architecture Support

- Intel x64: Full support with standard optimizations
- Apple Silicon (M1/M2/M3): ARM-optimized with Metal acceleration

## Manual Installation

If the automatic installer fails:

1. Install Homebrew: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
2. Install Python: `brew install python@3.11`
3. Run the installer: `./install.sh`

## Support

- Health check: `./healthcheck.sh`
- Documentation: See README.md files
- Troubleshooting: Check ~/ai-trading-bot/logs/
