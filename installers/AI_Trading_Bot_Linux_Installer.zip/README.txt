# AI Crypto Trading Bot - Linux Installation

## Quick Start

1. Open terminal
2. Navigate to this folder: `cd /path/to/this/folder`
3. Run: `./install.sh`
4. Follow the installation prompts
5. Configure API keys in .env file
6. Start service: `sudo systemctl start ai-trading-bot`

## Requirements

- Ubuntu 18.04+ / Debian 10+ / CentOS 7+ / RHEL 7+
- sudo privileges (for system packages and service installation)
- Internet connection

## Distribution Support

- Ubuntu/Debian: Full automatic installation
- CentOS/RHEL/Fedora: Full automatic installation  
- Other distributions: Manual dependency installation may be required

## Server Deployment

Perfect for VPS, cloud instances, and dedicated servers:

- Systemd service for 24/7 operation
- Automatic startup on boot
- Remote web access on port 5000/8501
- SSH tunnel support for secure access

## Manual Installation

If the automatic installer fails:

1. Install Python 3.8+: `sudo apt install python3 python3-pip python3-venv`
2. Install system packages: `sudo apt install build-essential git curl`
3. Run the installer: `./install.sh`

## Remote Access

- Direct: `http://server-ip:8501`
- SSH tunnel: `ssh -L 8501:localhost:8501 user@server-ip`
- See REMOTE_ACCESS_DEPLOYMENT_GUIDE.md for complete setup

## Support

- Health check: `./healthcheck.sh`
- Service status: `sudo systemctl status ai-trading-bot`
- View logs: `sudo journalctl -u ai-trading-bot -f`
- Documentation: See README.md files
