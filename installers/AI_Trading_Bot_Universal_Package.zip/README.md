# AI Crypto Trading Bot - Universal Installation Package

## Platform-Specific Installation

### Windows 10/11 x64
```
cd installers/windows
Right-click install.bat → "Run as administrator"
```

### macOS (Intel + Apple Silicon)
```
cd installers/macos
./install.sh
```

### Linux (Ubuntu/Debian/CentOS/RHEL)
```
cd installers/linux
./install.sh
```

## Manual Installation

If you prefer manual installation or the automatic installers fail:

1. Install Python 3.8+ for your platform
2. Install required packages: `pip install -r requirements.txt`
3. Run: `python advanced_ai_system.py`

## Quick Start

1. Run the appropriate installer for your platform
2. Configure API keys in `.env` file
3. Start the bot: `tradingbot` or `python advanced_ai_system.py`
4. Access web interface: `http://localhost:5000`

## Configuration

- Environment variables: `.env` file
- Main configuration: `config/config.yaml`
- Templates available in: `config_templates/`

## Documentation

- Complete deployment guide: `REMOTE_ACCESS_DEPLOYMENT_GUIDE.md`
- Platform-specific guides: `INSTALLATION_GUIDE_*.md`
- System health: Run `python check_install.py`

## Support

- Health check: `python check_install.py` (all platforms)
- Quick check: `./healthcheck.sh` (Linux/macOS)
- Logs: Check `logs/` directory
- System status: `python system_health_check.py`

## Features

- 24/7 autonomous trading with AI decision making
- Multi-exchange support (Binance, Coinbase, Bybit, OKX, Kraken)
- Advanced quantitative analysis with backtesting
- Real-time market sentiment analysis
- HuggingFace AI models integration
- Smart performance optimization
- Enterprise-grade security and encryption
- Remote access and deployment ready

Ready for live trading with real capital when properly configured.
