# AI Crypto Trading Bot - Windows Installation

## Quick Start

1. Right-click "install.bat" and select "Run as administrator"
2. Follow the installation prompts
3. Configure API keys in .env file
4. Run "tradingbot" from command line or use desktop shortcut

## Requirements

- Windows 10/11 x64
- Administrator privileges (for installation only)
- Internet connection for downloading dependencies

## Manual Installation

If the automatic installer fails:

1. Install Python 3.11 from python.org
2. Run: `powershell -ExecutionPolicy Bypass -File install.ps1`

## Support

- Health check: `python check_install.py`
- Documentation: See README.md files
- Troubleshooting: Check logs/ directory
